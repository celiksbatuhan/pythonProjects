n = int(input("Enter a number: "))
print(max(str(n)))
