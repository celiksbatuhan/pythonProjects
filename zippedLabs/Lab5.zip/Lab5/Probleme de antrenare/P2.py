n = int(input("Enter a number: "))
print(f"Number {n} in binary: {bin(n).removeprefix("0b")}")