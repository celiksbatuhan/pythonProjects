text = input("Enter a text: ")
print(text[::-1])