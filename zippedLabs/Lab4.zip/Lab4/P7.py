text = list(input("Enter a text: ").split())
text.sort()
for i in text:
    print(i)
