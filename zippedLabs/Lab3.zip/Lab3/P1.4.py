for i in range(1,7,1):
    print(i*'*',end='\n')
for i in range(5,0,-1):
    print(i*'*',end='\n')