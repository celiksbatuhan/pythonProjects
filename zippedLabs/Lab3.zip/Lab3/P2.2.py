i=0
n=input("Enter a number: ")
while i<len(n):
    print(n[len(n)-i-1],end='')
    i+=1