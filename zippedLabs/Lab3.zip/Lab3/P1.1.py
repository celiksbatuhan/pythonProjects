n=int(input("Enter a value for n: "))
for i in range(n):
    print(i,end=' ')