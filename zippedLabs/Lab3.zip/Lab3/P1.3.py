sum=0
n=input("Enter a number: ")
for i in n:
    sum+=int(i)
print(sum)