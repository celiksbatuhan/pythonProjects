n=int(input("Enter a number: "))
if n%2==0:
    print("It is an even number.")
else:
    print("It is an odd number.")