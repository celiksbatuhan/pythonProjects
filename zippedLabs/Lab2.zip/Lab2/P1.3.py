n=int(input("Enter a number: "))
print(hex(n))