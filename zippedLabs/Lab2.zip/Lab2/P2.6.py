n1=int(input("Enter the first number: "))
n2=int(input("Enter the second number: "))
if n1==n2:
    print("They are equal numbers.")
else:
    print(f"Max = {max(n1,n2)}\nMin = {min(n1,n2)}")