print("8x+16")
x=int(input("Enter a value for x: "))
print(8*x+16)