import math
r=float(input("Enter a number: "))
if r>0:
    print(f"Volume = {(4*math.pi*r**3)/3}\nArea = {4*math.pi*r**2}")