sentence=input("Enter a sentence: ")
for i in range(len(sentence)):
    if sentence[i]==' ':
        print(sentence[i].replace(' ','---'),end='')
    else:
        print(sentence[i], end='')
